#Para fazer a instalação do Highlight Syntax Tpp execute os seguites comandos:

`$ cp highlight_syntax_tpp.nanorc /usr/share/nano/`

`$ echo 'include "/usr/share/nano/highlight_syntax_tpp.nanorc"' >> ~/.nanorc`